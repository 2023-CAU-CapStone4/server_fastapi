from fastapi import FastAPI, Request, Depends
from sqlalchemy.orm import Session
import crud
import models
import database
from typing import Optional
from mangum import Mangum   

models.Base.metadata.create_all(bind=database.engine)

app = FastAPI()

def get_db() :
    db=database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

#지도 매물 위치 API
@app.get("/api/room")
def map_room(lbLat:float, lbLng: float, rtLat:float, rtLng:float, zoomin:Optional[int] =1, minRent: Optional[float]=-1, maxRent:Optional[float]=400000, type:Optional[int]=-1, minSize:Optional[float]=0, maxSize:Optional[float]=30961, minDeposit:Optional[int]=-1, maxDeposit:Optional[int]=350000, minManage:Optional[float]=0, maxManage:Optional[float]=9999, minFloor:Optional[int]=-999, maxFloor:Optional[int]=999,  db: Session = Depends(get_db)):
    print("--------parameter in api---------")
    print(f"{lbLat},{lbLng},{rtLat},{rtLng},{zoomin},{minRent},{maxRent},{type},{minSize},{maxSize},{minDeposit},{maxDeposit},{minManage},{maxManage},{minFloor},{maxFloor}" )
    
    print("--------------------------")
    #37.4850032626182,126.93150673092983  ->서울시 관악구 신림동
    #37.54496243752016,127.05811100268276 -> 서울시 성동구 성수동2가
    rooms = crud.room_by_coord(db ,lbLat,lbLng,rtLat,rtLng,zoomin,type,minSize,maxSize,minDeposit,maxDeposit,minRent,maxRent,minManage,maxManage,minFloor,maxFloor)
    return rooms

#추천 검색어 API
@app.get("/api/keyword")
def autoKeyword(word :str, db: Session = Depends(get_db)):
    keywords = crud.keyword_automake(db, word)
    return keywords
    
#매물 상세정보 API id -> 매물정보
@app.get("/api/detail")
def roomDetail(id:str, db:Session=Depends(get_db)):
    roomDetailInfo = crud.roomDetail(db,id)
    return roomDetailInfo

#검색어 입력시 해당 매물 리스트 API
@app.get("/api/list")
def listRoom(addr: str, count: Optional[float]=100 , sort:Optional[int]=1,  db:Session=Depends(get_db)):
    keywords = crud.list_rooms(db, addr, count, sort)
    
    
    return keywords

@app.get("/api/testForsubway")
def listSubways(db:Session = Depends(get_db)):
    result = crud.getCoordinateFromSubwayTable(db)
    return result

handler = Mangum(app)