import requests
from fastapi import FastAPI
from fastapi.responses import FileResponse

app = FastAPI()

@app.get("/image")
async def get_image():
    # Parse the image URL from web crawling
    image_url = "https://ic.zigbang.com/ic/items/33852789/1.jpg?w=400&h=300&q=70&a=1"
    response = requests.get(image_url)
    with open("image.jpg","wb") as file:
        file.write(response.content)
        
    # Set the appropriate content type for the image
    content_type = "image/jpeg"  # Adjust this based on the image format
    
    # Send the image URL as a response
    return FileResponse("image.jpg", media_type=content_type)