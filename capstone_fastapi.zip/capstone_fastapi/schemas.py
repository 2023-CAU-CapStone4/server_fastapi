from pydantic import BaseModel

class MapBase(BaseModel):
    lat: float
    lng: float
    zoomlevel: int