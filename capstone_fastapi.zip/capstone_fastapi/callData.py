import pandas as pd
import matplotlib.pyplot as plt
import pymysql


connection = pymysql.connect(host='room-easy.c3men8lgpfc5.ap-northeast-2.rds.amazonaws.com', port=3306, user='root', password='roomeasy0517', db='capstone', charset='utf8')
cursor = connection.cursor()
# Excel 파일 읽기
df_from_excel = []
for count in range(96) :
    
    print("count :", count)  
    df_from_excel.append(pd.read_excel('./room_data/output_2023_06_03_13_18_55738462_'+str(count)+'.xlsx', sheet_name='Sheet1'))

# 'column_name' 컬럼(열) 추출
lat = []
lng = []
point = df_from_excel[0]['random_location'].to_dict()
finalpoint = point[0]
#58번 loop문을 돎
for extract in range(96) :
    data = df_from_excel[extract]['random_location'].to_dict()
    
    #print(data)
    #print(len(data))
    #print(data[0])
    for extract2 in range(len(data)) :
        
        read = 0
        tmp = ""
        for value in data[extract2] :
            if value == ',':
                lat.append(float(tmp))
                tmp = ""
                read = 0
                continue
            elif value == '}':
                lng.append(float(tmp))
                tmp = ""
                read = 0
                continue
            elif read == 1 :
                tmp += value  
            elif value == ':' :
                read = 1
                continue
print("lat", len(lat))
print("lat", len(lng))
print("type : ", type(lat[0]))
print("one point in df : ",finalpoint)
print("one point : ", lat[0],",",lng[0])
print("min lat" , min(lat))
print("max lat" , max(lat))
print("min lng" , min(lng))
print("max lng" , max(lng))
#plt.scatter(lng,lat)
#plt.show()
print("df_from_excel len : ", len(df_from_excel))
for i in range(96) :
    data = df_from_excel[i]
    
    '''print(data.loc[0]['item_id'])
    print(data.loc[0]['address1'])
    print(data.loc[0]['deposit'])
    print(data.loc[0]['rent'])
    print(data.loc[0]['manage_cost'])
    print(data.loc[0]['service_type'])
    print(data.loc[0]['sales_type'])
    print(data.loc[0]['random_location'])'''
    print("data len : ", len(data))
    for j in range(900):
        id = data.loc[j]['item_id']
        print("id : ", id)
        address = data.loc[j]['address1']
        print("address : ", address)
        deposit = data.loc[j]['deposit']
        print("deposit : ", deposit)
        floor = data.loc[j]['floor']
        print("floor : ", floor)
        images_thumbnail = data.loc[j]['images_thumbnail']
        print("images_thumbnail : ", images_thumbnail)
        rent = data.loc[j]['rent']
        print("rent : ", rent)
        manage_cost = data.loc[j]['manage_cost']
        print("manage_cost : ", manage_cost)
        service_type = data.loc[j]['service_type']
        print("service_type : ", service_type)
        sales_type = data.loc[j]['sales_type']
        print("sales_type : ", sales_type)
        random_location = data.loc[j]['random_location']
        print("random_location : ", random_location)
        latitude = lat[900*i+j] 
        print("type : ", type(latitude))
        print("latitude : ", latitude)
        longitude = lng[900*i+j]
        print("type : ", type(longitude))
        print("longitude : ", longitude)
        size_m2 = data.loc[j]['size_m2']
        print("type : ", type(size_m2))
        print("size_m2 : ", size_m2)
        vals = (id, deposit, address, floor,images_thumbnail, rent, manage_cost, service_type, sales_type, latitude,longitude,size_m2)
        sql="INSERT INTO room VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        cursor.execute(sql,vals)

        
        
connection.commit()
connection.close()

        
        
    
    