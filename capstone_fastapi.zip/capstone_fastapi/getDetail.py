import requests
import pymysql

def get_location_from_id(id: str) :
    
    connection = pymysql.connect(host='room-easy.c3men8lgpfc5.ap-northeast-2.rds.amazonaws.com', port=3306, user='root', password='roomeasy0517', db='capstone', charset='utf8')
    cursor = connection.cursor()
    #vals = (id, deposit, address, floor,images_thumbnail, rent, manage_cost, service_type, sales_type, latitude,longitude,size_m2)
    sql="SELECT latitude,longitude from room where id =" + id
    cursor.execute(sql)
    results = cursor.fetchall()
    
    connection.commit()
    connection.close()
    
    return results

'''if len(get_location_from_id("31820455")) == 1 :
    print("latitude : " ,get_location_from_id("31820455")[0][0] )
    print("longitude : " ,get_location_from_id("31820455")[0][1] )
'''
'''def putData_to_broker_roomTable(ids):
    connection = pymysql.connect(host='room-easy.c3men8lgpfc5.ap-northeast-2.rds.amazonaws.com', port=3306, user='root', password='roomeasy0517', db='capstone', charset='utf8')
    cursor = connection.cursor()
    for i in ids: 
        sql = "insert into broker_room(user_id, room_id) values (2,"+ i +")"
    #sql="INSERT INTO broker_room VALUES ()"
        cursor.execute(sql)

        print(i)
    connection.commit()
    connection.close()'''
#idArray = call_ids_FromDB()
#putData_to_broker_roomTable(idArray)
def getEnvironmentInfo(room_id : str) :
    url = "https://apis.zigbang.com/v2/items/"+room_id
    response = requests.get(url)
    if response.status_code == 200:
        # Request was successful
        data = response.json()
        # Analyze the response data here
        #print(data)
        roomId=''
        jibunAddr=''
        describe=''
        environment=''
        amenities=''
        subways=''
        if 'item' in data :
            if 'item_id' in data['item']:
                roomId = data['item']['item_id']
                #print("======= roomId during Collection ========> ",roomId )
            if 'jibunAddress' in data['item']:
                jibunAddr = data['item']['jibunAddress']
                print("======= jibunAddr during Collection ========> ",jibunAddr )
            if 'title' in  data['item']:
                describe = data['item']['title']
                #print("======= describe during Collection ========> ",describe )
            if 'neighborhoods' in  data['item']:
                if 'amenities' in  data['item']['neighborhoods']:
                    amenities = data['item']['neighborhoods']['amenities']
                    print("======= amenities during Collection ========> ",amenities )
                if 'nearbyPois' in data['item']['neighborhoods']:
                    environment = data['item']['neighborhoods']['nearbyPois']
                    print("======= environment during Collection ========> ",environment )
        
        if 'subways' in data:
            subways = data['subways']
            print("======= subways during Collection ========> ",subways )
        
        
        data_amenities = []    
        if amenities != '':
            for data in amenities :
                data_amenities.append(data['description'])
        data_Environment=[]    
        if environment != '':  
            for data in environment :
                if data['exists'] == True :
                    tmp =''
                    if data['transport'] == 'foot' :
                        tmp = '도보'
                    elif   data['transport'] == 'car' :
                        tmp = '차량'
                    data_Environment.append({
                        'type': data['poiType'],
                        'distance': data['distance'],
                        'time':data['timeTaken']//60+1,
                        'transport':tmp,
                    })
            
        result = {
            "id" : roomId,
            "addr" : jibunAddr,
            "explain" : describe,
            "subways" : subways,
            "amenities" : data_amenities,
            "environment" : data_Environment,
        }
        return result
    return -1
    
'''ids = call_ids_FromDB()
error = 0
abnormalSubway = 0
abnormalEnvir = 0
for i in ids[:100]:
    result = getEnvironmentInfo(i)
    if result == -1 :
        error +=1
    else:
        if len(result["amenities"]) == 0 or len(result["environment"]) == 0 :
            abnormalEnvir+=1
        if len(result["subways"]) == 0:
            abnormalSubway+=1
            
print(error)
print(abnormalEnvir)
print(abnormalSubway)
#print("getEnvironmentInfo : ", getEnvironmentInfo("36762806"))
#keyword = "34763300"
#print("-- "+keyword+" room Info --\n",getEnvironmentInfo(keyword),"\n--------------------\n")'''