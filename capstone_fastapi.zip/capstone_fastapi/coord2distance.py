from math import radians, sin, cos, sqrt, atan2

def calculate_distance(lat1, lon1, lat2, lon2):
    # Convert latitude and longitude from degrees to radians
    lat1 = radians(lat1)
    lon1 = radians(lon1)
    lat2 = radians(lat2)
    lon2 = radians(lon2)

    # Radius of the Earth in meters
    radius = 6371000

    # Difference in coordinates
    dlat = lat2 - lat1
    dlon = lon2 - lon1

    # Haversine formula
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * atan2(sqrt(a), sqrt(1-a))

    # Calculate the distance
    distance = radius * c
    return distance
lat1 = 37
lon1 = 126
lat2 = 37.03
lon2 = 126.03
distance = calculate_distance(lat1, lon1, lat2, lon2)
#print(f"The distance between the coordinates is approximately: {distance} meters")
'''
# Example usage
lat1 = 37
lon1 = 126
lat2 = 37
lon2 = 126.05
str1 = "37.528326654172645"
print("str1 : ", str1)
print("str1 -> float : ", float(str1))
print(float(str1)+lat1)
# test 서울시 영등포구 당산동 : (37.528326654172645, 126.90667685642404)  id : 35145546
# test 서울시 관악구 신림동 (37.4850032626182,126.93150673092983) id : 34026645
distance = calculate_distance(lat1, lon1, lat2, lon2)
print(f"The distance between the coordinates is approximately: {distance} meters")'''