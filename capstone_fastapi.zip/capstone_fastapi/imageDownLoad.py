import requests

#직방 매물 썸네일 이미지 다운로드 하는법
image_url = "https://ic.zigbang.com/ic/items/35145546/1.jpg?w=400&h=300&q=70&a=1"
filename = "photo.jpg"

response = requests.get(image_url)

if response.status_code == 200:
    with open(filename, 'wb') as file:
        file.write(response.content)
    print("Photo downloaded successfully!")
else:
    print("Failed to download the photo.")