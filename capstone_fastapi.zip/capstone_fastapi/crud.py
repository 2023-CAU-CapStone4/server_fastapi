from sqlalchemy.orm import Session
from sqlalchemy import and_, func, or_, not_
import models
from math import sqrt
import random
import coord2distance
import getDetail
import geoCoding

# 두 위도,경도 쌍 사이의 직선거리
def calculate_distance(lat1, lng1, lat2, lng2):
    return sqrt((lat2 - lat1)**2 + (lng2 - lng1)**2)

#"월세" 기준으로 정렬 "전세는" 뒤쪽으로
def custom_sort_key(item):
    if item["type"] == "월세":
        return float(item["rent"])  # Convert "rent" to an integer for numerical comparison
    else:
        return float('inf')  # Place non-"monthly rent" items at the end of the sorted list
    
#지도 boundary와 center coordinate 기준으로 매물 조회 
def room_by_coord(db: Session, lbLat:float, lbLng: float, rtLat:float, rtLng:float, zoomin:int, saletype: int, minSize: float, maxSize:float, minDeposit:int, maxDeposit:int,  minRent:float, maxRent:float, minCost:float , maxCost:float, minFloor:int, maxFloor:int ):
    
    max_lat = rtLat
    min_lat = lbLat
    max_lng = rtLng
    min_lng = lbLng
    #if saletype == -1:
        
    query = db.query(models.Room).filter(and_(
        models.Room.latitude < max_lat,
        models.Room.latitude > min_lat,
        models.Room.longitude < max_lng,
        models.Room.longitude > min_lng,
        models.Room.rent>=minRent,
        models.Room.rent<=maxRent,
        models.Room.size_m2>=minSize,
        models.Room.size_m2<=maxSize,
        models.Room.deposit>=minDeposit,
        models.Room.deposit<=maxDeposit,
        models.Room.manage_cost>=minCost,
        models.Room.manage_cost<=maxCost,  
    ))
    if query.count()>500:
        print("너무 많은 매물이 조회되어 반환 값이 없습니다. --> ",query.count(),"개")
        return "null"
    
    if saletype == 0:
        query = query.filter(models.Room.sales_type=="전세")
        print("query Count_ 전세 : ", query.count())
    elif saletype == 1:
        query = query.filter(models.Room.sales_type=="월세")
        print("query Count_ 월세 : ", query.count())
    
    if maxFloor < 10 :
        query = query.filter(or_(and_(
            models.Room.floor>=str(minFloor),
            models.Room.floor<=str(maxFloor),
            ),
            models.Room.floor =="반지하",  
            models.Room.floor =="저",                     
        )
        )
    
    elif maxFloor <30:
        query = query.filter(or_(and_(
            models.Room.floor>=str(minFloor),
            models.Room.floor<=str(maxFloor),
            ),
            models.Room.floor =="중",     
            models.Room.floor =="반지하",  
            models.Room.floor =="저",                  
        )
        )
    elif maxFloor > 30:    
        query = query.filter(or_(and_(
            models.Room.floor>=str(minFloor),
            models.Room.floor<=str(maxFloor),
            ),
            models.Room.floor =="옥탑방",  
            models.Room.floor =="고",  
            models.Room.floor =="초고",    
            models.Room.floor =="중",     
            models.Room.floor =="반지하",  
            models.Room.floor =="저",                     
        )
        )
        
    records = query.all()
    roomNum = query.count()
    print(f"{coord2distance.calculate_distance(lbLat,lbLng, rtLat, rtLng)}m 내의 매물들을 조회하였습니다.")
    print(f"{roomNum}개의 매물이 조회되었습니다.")
    #거리가 가까운 순으로 정렬
    result = []
    addr = []
    index = []
    fullAddr = []
    records = sorted(records, key=lambda record: calculate_distance((lbLat+rtLat)/2,(lbLng+rtLng)/2, record.latitude, record.longitude))
    
    if zoomin == 1:
        for i in records:
            if i.sales_type == "전세" :
                result.append({
                'id':i.id,
                'lat':i.latitude,
                'lng':i.longitude,
                'price':i.deposit,
                'size':(i.size_m2),
            })    
            elif i.sales_type == "월세" :
                result.append({
                'id':i.id,
                'lat':i.latitude,
                'lng':i.longitude,
                'price':i.rent,
                'size':(i.size_m2),
            })
        return result
    else :
        for i in records:
            fullAddr.append(i.address)
        setFullAddr = set(fullAddr)
        non_duplicate_Fulladdr = list(setFullAddr)
        for i in non_duplicate_Fulladdr :
            addr.append(i.split()[-1])
        #setAddr = set(addr)
        #non_duplicate_addr = list(setAddr)
        print(f"--{len(addr)}개의 주소가 조회되었습니다.-- \n {addr} ")
        for j in addr:
            
            tmp = []
            for k in range(len(records)):
                if records[k].address.split()[-1] == j :
                    print()
                    tmp.append(k)
            index.append(tmp)
        print(f"{len(index)}개의 매칭된 인덱스 쌍입니다.\n {index}")
        seq = 0
        #print(records[0].latitude)
        #print(type(records[0].latitude))
        
        for t in index:
            ids = []
            latSum = 0.0
            lngSum = 0.0
            prices = []
            for val in t :
                ids.append(records[val].id)
                latSum += (records[val].latitude)
                lngSum += (records[val].longitude)
                prices.append(records[val].rent)
            latMean = latSum/len(t)
            lngMean = lngSum/len(t)
            
            result.append({
                "ids": ids,
                "lat": latMean,
                "lng": lngMean,
                "minPrice": min(prices),
                "FullName": non_duplicate_Fulladdr[seq],
                "dongName": addr[seq],
                "roomNum" :len(t)
            }) 
            
            seq +=1
        tolessDong = []
        response = []
        for i in result :
            if i["roomNum"] < 15 :
                    tolessDong.append(i)
            else :
                    response.append(i)
                    
        if len(tolessDong) > 0 :
                tolessDong_latSum = 0
                tolessDong_lngSum = 0
                tolessDong_roomNum = 0
                tolessDong_ids = []
                tolessDong_price = []
                for i in tolessDong :
                    tolessDong_latSum += i["lat"]
                    tolessDong_lngSum += i["lat"]
                    tolessDong_roomNum += i["roomNum"]
                    tolessDong_ids += i["ids"]
                    tolessDong_price.append(i["minPrice"])
                response.append({
                    "ids": tolessDong_ids,
                    "lat": tolessDong_latSum/tolessDong_roomNum,
                    "lng": tolessDong_latSum/tolessDong_roomNum,
                    "minPrice": min(tolessDong_price),
                    "FullName": tolessDong[0]["FullName"],
                    "dongName": tolessDong[0]["dongName"],
                    "roomNum" :tolessDong_roomNum
                })
            
        
        
        return response    
                
#키워드 검색 시 관련 매물 조회      
def list_rooms(db:Session, address: str, count: int, sort:int):
    db_address = matching_keyword_db(db, address)
    print(address+"와 매칭된 주소 : ", db_address)
    #db에서 매칭된 주소가 있다면 매칭되는 레코드를 수집해서 뿌려준다.
    result = []
    if len(db_address) == 1 :
        matchRecords = []
        extendRecords = []
         
        match_record =  db.query(models.Room).filter(models.Room.address == db_address[0]).all()
        print(f"{len(match_record)}개의 레코드가 매칭되었습니다.")
        
        latTotal = [data.latitude for data in match_record]
        lngTotal = [data.longitude for data in match_record]
        
        #print("db에서 추출한 위도 모음 : ",latTotal)
        #print("db에서 추출한 경도 모음 : ",lngTotal)
        
        lat = sum(latTotal)/len(latTotal)
        lng = sum(lngTotal)/len(lngTotal)
        print("db에서 추출한 위도들의 평균 : ",lat)
        print("db에서 추출한 경도들의 평균 : ",lng)
        
        match_record = sorted(match_record, key=lambda record: calculate_distance(lat,lng, record.latitude, record.longitude))
        
        for i in match_record :
            matchRecords.append(
                {
                "id" : i.id,
                "address" : i.address,
                "type" : i.sales_type,
                "rent" : str(i.rent),
                "size" : str(i.size_m2),
                "deposit" : str(i.deposit),
                "image" : i.images_thumbnail,
            }
            )    
            
        '''extend_records = db.query(models.Room).filter(and_(
            models.Room.latitude > lat-0.03,
            models.Room.longitude > lng-0.03,
            models.Room.latitude < lat+0.03,
            models.Room.longitude < lng+0.03,
        )
        ).all()
        
        extend_records = sorted(extend_records, key=lambda record: calculate_distance(lat,lng, record.latitude, record.longitude))
        
        for i in extend_records :
            extendRecords.append(
                {
                "id" : i.id,
                "address" : i.address,
                "type" : i.sales_type,
                "rent" : str(i.rent),
                "size" : str(i.size_m2),
                "deposit" : str(i.deposit),
                "image" : i.images_thumbnail,
            }
            ) 
        
        for dictionary in matchRecords:
            if not any(d['id'] == dictionary['id'] for d in result):
                result.append(dictionary)

        for dictionary in extendRecords:
            if not any(d['id'] == dictionary['id'] for d in result):
                result.append(dictionary)'''
        for dictionary in matchRecords:
            result.append(dictionary)
        #print(result)  
        print("result_반환 매물 개수 : ", len(result))
        
        if sort == 2:
            result = sorted(result, key=lambda record: custom_sort_key(record))
        elif sort == 3:
            result = sorted(result, key=lambda record: -float(record['size']))
        
        respone = []
        if len(result) < 100 :
            return result
        else :
            for i in range(int(count)):
                    respone.append(result[i])
                    
        print("respone_반환 매물 개수 : ", len(respone))
        
        return respone
        
    else:
        print("DB에서 매칭되는 주소가 없습니다.")
        '''if geoCoding.extractCoord(address) == -1 :
            print("지오코딩 함수로 매칭되는 주소가 없습니다")
            return -1'''
        lat = geoCoding.extractCoord(address)[0]
        lng = geoCoding.extractCoord(address)[1]
        records = db.query(models.Room).filter(and_(
            models.Room.latitude > lat-0.03,
            models.Room.longitude > lng-0.03,
            models.Room.latitude < lat+0.03,
            models.Room.longitude < lng+0.03,
        )
        ).all()
        records = sorted(records, key=lambda record: calculate_distance(lat,lng, record.latitude, record.longitude))
        for i in records :
            result.append({
                "id" : i.id,
                "address" : i.address,
                "type" : i.sales_type,
                "rent" : str(i.rent),
                "size" : str(i.size_m2),
                "deposit" : str(i.deposit),
                "image" : i.images_thumbnail,
            })
        print("result_반환 매물 개수 : ", len(result))
        
        if sort == 2:
            result = sorted(result, key=lambda record: custom_sort_key(record))
        elif sort == 3:
            result = sorted(result, key=lambda record: -float(record['size']))
        respone = []
        if len(result) < 100 :
            return result
        else :
            for i in range(int(count)):
                    respone.append(result[i])
        
        print("respone_반환 매물 개수 : ", len(respone))
        
        return respone
    
# 매물 상세보기
def roomDetail(db:Session, id: str):
    response = []
    # room 테이블에 있는 정보
    record = db.query(models.Room).filter(models.Room.id == id).all()
    
    # broker_room 테이블에 있는 정보
    brokerQuery = db.query(models.Broker).filter(models.Broker.room_id == int(id))
    print(f"{brokerQuery.count()}개의 공인중개사가 검색되었습니다.")
    brokerInfo = []
    
    
    
    # id로 검색된 data 가져옴
    for i in record :
        data=i
    
    subwayCrowding = []
    subwayCoorRecord = db.query(models.SubwayInfo).all()
    subwayInfo = []
    for i in subwayCoorRecord :
        if coord2distance.calculate_distance(i.lat, i.lng, data.latitude, data.longitude) < 1500 :
            subwayInfo.append({
                "id" : i.id,
                "name" : i.name,
                "lineNum" : i.line_num,
                "description" : str(i.line_num) + "호선",
                "distance" :  int(coord2distance.calculate_distance(i.lat, i.lng, data.latitude, data.longitude)),
                "time" : int(((coord2distance.calculate_distance(i.lat, i.lng, data.latitude, data.longitude)/1000)/5)*60)
            })
    print ("subway info ==> ", subwayInfo)
    
    for j in range(len(subwayInfo)) :
        crowdingRecord = db.query(models.SubwayCrowding.time_7_00,models.SubwayCrowding.time_12_00,models.SubwayCrowding.time_18_00,models.SubwayCrowding.time_23_00).filter(and_(
          models.SubwayCrowding.line_number == subwayInfo[j]["lineNum"],
          models.SubwayCrowding.start_station == subwayInfo[j]["name"]
        )).first()
        subwayInfo[j]["crowding"] = [crowdingRecord.time_7_00,crowdingRecord.time_12_00,crowdingRecord.time_18_00,crowdingRecord.time_23_00] 
        
        
    #print(subwayQuery[0][0])
    #print(subwayQuery[0][1])
    for j in brokerQuery.all() :
        #공인중개사 수집
        brokerInfo.append(
            {
                "id" : j.id,
                "user_id" : j.user_id,
                "room_id" : j.room_id,
                "created_at" : j.created_at,
                "updated_at" : j.updated_at
            }
        )
    
    for i in range(len(brokerInfo)) :
        userQuery = db.query(models.User).filter(models.User.id == brokerInfo[i]["user_id"]).first()
        brokerInfo[i]["email"] = userQuery.email
        brokerInfo[i]["name"] = userQuery.name
        
        
    print("== BROKER INFORMATION ==\n",brokerInfo, "====================")
    requestFromZigbang = getDetail.getEnvironmentInfo(id)
    
    #직방에서 environmentInfo 를 가져왔을 때
    if requestFromZigbang != -1 :
        if len(requestFromZigbang['environment']) == 0 :
            distanceSum = 0
            if len(subwayInfo) != 0 :
                for d in subwayInfo :
                    distanceSum += d["distance"]
                requestFromZigbang['environment'].append({
                "type" : "지하철역",
                "distance" : int(distanceSum/len(subwayInfo)),
                "time" : int(((distanceSum/len(subwayInfo))/5000)*60),
                "transport" : "도보",
                })
            else :
                
                if len(requestFromZigbang["subways"]) != 0:
                    distanceSum = 0  
                    for d in requestFromZigbang["subways"] :
                        lat = geoCoding.extractCoord(d['name'])[0]
                        lng = geoCoding.extractCoord(d['name'])[1]
                        if coord2distance.calculate_distance(data.latitude,data.longitude,lat,lng) < 3000 :
                            distanceSum += coord2distance.calculate_distance(data.latitude,data.longitude,lat,lng)
                    requestFromZigbang['environment'].append({
                    "type" : "지하철역",
                    "distance" : int(distanceSum/len(requestFromZigbang["subways"])),
                    "time" : int(((distanceSum/len(requestFromZigbang["subways"]))/5000)*60),
                    "transport" : "도보",
                })
        print("-- data From Zigbang\n",requestFromZigbang,"\n---------")
        response.append({
            "address":requestFromZigbang['addr'],
            "images_thumbnail":data.images_thumbnail,
            "manage_cost": data.manage_cost,
            "sales_type":data.sales_type,
            "longitude": data.longitude,
            "deposit": data.deposit,
            "id": data.id,
            "floor": data.floor,
            "rent": data.rent,
            "service_type": data.service_type,
            "latitude": data.latitude,
            "size_m2": data.size_m2,
            "amenities":requestFromZigbang['amenities'],
            "nearSubway" : subwayInfo,
            "explain" : requestFromZigbang['explain'],
            "environment" : requestFromZigbang['environment'],
            "brokerInfo" : brokerInfo
        })
        
    else :
        response.append({
            "address":data.address,
            "images_thumbnail":data.images_thumbnail,
            "manage_cost": data.manage_cost,
            "sales_type":data.sales_type,
            "longitude": data.longitude,
            "deposit": data.deposit,
            "id": data.id,
            "floor": data.floor,
            "rent": data.rent,
            "service_type": data.service_type,
            "latitude": data.latitude,
            "size_m2": data.size_m2,
            "brokerInfo" : brokerInfo
        })
        
        
    return response
        
# 검색어 자동완성
def keyword_automake(db: Session, keyword: str):
    query = db.query(models.Room.address).distinct()
    keywords = query.all()
    print(keywords)
    result = []
    for data in keywords:
        if keyword in data["address"] :
            result.append(data["address"])
    
    if len(result) > 10 :
        random_indices=random.sample(range(len(result)),10)
        fullResult = [result[index] for index in random_indices]
    else :
        fullResult = result
    
    dongResult = []
    for i in fullResult:
        dongResult.append(i.split()[-1])
        
    respone = []
    for j in range(len(fullResult)):
        respone.append({"full" :fullResult[j], "dong":dongResult[j] })
        
    addressNum = query.count()
    
    print(f"{addressNum}개의 주소가 검색되었습니다.")
    
    return respone

# 키워드 - DB 매칭
def matching_keyword_db(db: Session, keyword: str):
    query = db.query(models.Room.address).distinct()
    keywords = query.all()
    #print(f"{len(keywords)}개의 주소가 검색되었습니다.--> {keywords}")
    result = []
    for data in keywords:
        if keyword == data["address"] :
            result.append(data["address"])
    #print("matching address result --> ",result)
    
    return result

def getCoordinateFromSubwayTable(db: Session):
    query1 = db.query(models.SubwayCrowding.line_number,models.SubwayCrowding.start_station).distinct()
    query2 = db.query(models.SubwayInfo.line_num,)
   
    return 0