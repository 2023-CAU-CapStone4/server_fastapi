from geopy.geocoders import Nominatim

def extractCoord(addr: str):    
    # Create a geocoder instance
    geolocator = Nominatim(user_agent="sykim_geo")

    # Geocode the address
    location = geolocator.geocode(addr)
        
        # Extract latitude and longitude
    latitude = location.latitude
    longitude = location.longitude
    print("변환된 주소입니다 . " , latitude ,",", longitude)
    return [latitude, longitude]
    
#print(extractCoord("서울특별시 중구 세종대로 지하2"))
