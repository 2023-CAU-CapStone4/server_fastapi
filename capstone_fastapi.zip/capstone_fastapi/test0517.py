import requests

#직방 매물 썸네일 이미지 다운로드 하는법
str = '서울시'
image_url = f"http://localhost:8000/api/keyword?word={str}"
filename = "photo.jpg"

response = requests.get(image_url)

if response.status_code == 200:
    print("---result---")
    print(response.body)    
else:
    print("Failed to download the photo.")