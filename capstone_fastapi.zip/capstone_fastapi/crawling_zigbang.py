import requests
import json
import geohash2
import pandas as pd
import urllib.parse
from datetime import datetime
import os

#dong_info.txt 파일에서 "xx동" 정보를 읽어옴
dongInfo = []
with open("dong_info.txt", encoding="utf-8") as file :
    for line in file:
        dongInfo.append(line.strip())
        
print(dongInfo)

def subwayInfo(num):
    print("inuput" + num)
    response = requests.get("https://apis.zigbang.com/v2/subways/44")
    if response.status_code == 200:
        print(response.json())
    else:
        print("error in get subway info")

#print(subwayInfo("num"))
def get_address2geohash(name) :
    location = [] #위치정보를 담을 리스트
    addr=name #좌표로 변환할 지역명
    response = requests.get('https://apis.zigbang.com/v2/search?leaseYn=N&q='+addr+'&serviceType=원룸')
    if response.status_code == 200 :
        data = response.json()["items"] #data는 "흑석동"에 맞는 위치 정보
        #print("\n----------------------------"+addr+" 위도,경도----------------------------")
        #print(data)
        #print("-------------------------------------------------------------------------")
        
        #items에 있는 값을 하나씩 가져와 [위도,경도] 쌍을 추출
        for val in data :
            location.append([val["lat"],val["lng"]]) #[위도,경도] 쌍을 location 배열에 append
            #print(val["lat"])
            #print(val["lng"],"\n")
        
        #print("최종 위치 좌표 : ", location)
        geohash=[] # location에 있는 [위도,경도]쌍을 geohash 값으로 변경, precision은 hash 값 길이
        for val in location:
            geohash.append(geohash2.encode(val[0], val[1], precision = 5))
            #geohash.append(geohash2.encode(val[0], val[1]))
        #print("\n위도,경도를 geohash로 변환한 결과 : ",geohash)
        return geohash
    else:
        print("error in search lat, lng")

dongGeo = []
for value in dongInfo :
    if value != "" :
        data = get_address2geohash(value)
        for i in data :
            dongGeo.append(i)
dongGeo = list(set(dongGeo))
print(dongGeo)
print(len(dongGeo))
#print(get_address2geohash("흑석동"))

#geohash값에 포함되는 매물 ID 추출
def getid_from_geohash(geohash) :
    geoCode = geohash
    #geohash 값이 wydm2를 가지는 item(매물)들을 가져와서 id만 추출
    ids = []
    response = requests.get('https://apis.zigbang.com/v2/items?deposit_gteq=0&domain=zigbang&geohash='+geoCode+'&needHasNoFiltered=true&rent_gteq=0&sales_type_in=전세|월세&service_type_eq=원룸')
    if response.status_code == 200:
        items = response.json()["items"]
        for val in items :
             ids.append(val['item_id'])

        #중복되는 값이 있는지 확인
        '''if len(ids) != len(set(ids)):
            print("Duplicate values found in the array")
        else:
            print("No duplicate values in the array")
        print("--------------------------------------------------------------ids size--------------------------------------------------------------")
        print(len(ids))
        print("------------------------------------------------------------------------------------------------------------------------------------")
        '''
        return ids
    else:
        print("getting error from id value in proper area")

oneroomId = []
for i in dongGeo :
    data = getid_from_geohash(i)
    for j in data : 
        oneroomId.append(j)
oneroomId = list(set(oneroomId))
print("--------------------------------extracted oneroomId----------------------------------")
#print(oneroomId)
print(len(oneroomId))
print("---------------------------------------------------------------------------")


#print("--------------------------------------------------------------ids value--------------------------------------------------------------")    
#print("ids : ", ids)
#print("------------------------------------------------------------------------------------------------------------------------------------\n")
# Clean up the ids list by properly encoding each item
#print("----------------------------data for request_post to /v2/items/list -----------------------")
#print(ids[:15])
#print("-------------------------------------------------------------------------------------------\n")
def getdetailInfoById(idArray) :
    url = "https://apis.zigbang.com/v2/items/list"
    params = {
        "domain" : "zigbang",
        "item_ids" : idArray,
    }
    response = requests.post(url,params)
    if response.status_code==200:
        items = response.json()["items"]
        #print("------------------------------------response_ items---------------------------------------------")
        #print(items)
        #print(len(items))
        #print("------------------------------------------------------------------------------------------------")
        return items
        #colums=["item_id","address1", "deposit", "rent", "manage_cost", "service_type","sales_type","random_location" ]
        #index = []
        #for count in range(len(items)):
        #    index.append(count)
        #print("index:",index)
        #df = pd.DataFrame(items,index,colums)
        #print("------------------------------extracted detail info is returned-> structure is dataframe------------------------------")
        #return df
    else : 
        print("-------------------------------------response error-------------------------------------")
        print(response.text)
extractedData = []

for i in range(len(oneroomId)//900) :
    
    extractedData.append(getdetailInfoById(oneroomId[900*i:900*i+900]))
    
colums=["item_id","address1", "deposit", "floor","images_thumbnail","rent", "manage_cost", "service_type","sales_type","random_location" ,"size_m2"]

current_time = str(datetime.now())
current_time = current_time.replace(' ','_')
current_time = current_time.replace('-','_')
current_time = current_time.replace(':','_')
current_time = current_time.replace('.','')
print(len(extractedData))
for count in range(len(extractedData)):
    print("count:",count)
    index = []
    for count2 in range(len(extractedData[count])):
        index.append(count2)
    print("len index : ", len(index))
    df = pd.DataFrame(extractedData[count],index,colums)
    print("type" , type(df['random_location']))
    with pd.ExcelWriter('./room_data/output_'+current_time+'_'+str(count)+'.xlsx') as writer:
        df.to_excel(writer, sheet_name='Sheet1')

print(extractedData[0][0])

'''
print(current_time)
    print("---------------------------------------------------------------------------------")
'''
'''
params = {
    "domain": "zigbang",
    "withCoalition": True,
    "item_ids": ids[:900]
}
'''
'''
colums = ["item_id", "address1", "sales_type", "deposit", "rent", "manage_cost"]

df = pd.DataFrame(items_detail)[colums]
'''
