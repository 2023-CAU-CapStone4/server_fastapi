import pandas as pd
import matplotlib.pyplot as plt
import pymysql

'''
connection = pymysql.connect(host='room-easy.c3men8lgpfc5.ap-northeast-2.rds.amazonaws.com', port=3306, user='root', password='roomeasy0517', db='capstone', charset='utf8')
cursor = connection.cursor()
data = pd.read_csv('./subway_info.csv', encoding='euc-kr')
data.columns = ['INDEX', 'LINE', 'UNIQUENUM', 'NAME', 'LAT', 'LNG', 'DATE']
for i in range(len(data)):
    index = int(data.loc[i]["INDEX"])
    line = int(data.loc[i]["LINE"])
    #uniqueNum = data.loc[i]["UNIQUENUM"]
    name = str(data.loc[i]["NAME"])
    lat = float(data.loc[i]["LAT"])
    lng = float(data.loc[i]["LNG"])
    
    vals = (index, line, name, lat,lng)
    sql="INSERT INTO subwayCoord VALUES(%s,%s,%s,%s,%s)"
    cursor.execute(sql,vals)
        
connection.commit()
connection.close()

'''