from pydantic import BaseModel
from sqlalchemy import Boolean, String, Column, Float, Integer, DateTime
from sqlalchemy.orm import relationship
from database import Base

class Room(Base):
    __tablename__ = "room"
    
    id = Column(String, primary_key=True) 
    deposit = Column(Integer)
    address = Column(String)
    floor = Column(String)
    images_thumbnail = Column(String)
    rent = Column(Float)
    manage_cost = Column(Float)
    service_type = Column(String)
    sales_type = Column(String)
    latitude = Column(Float) 
    longitude= Column(Float)
    size_m2=Column(Float) #12
    
class Broker(Base):
    __tablename__ = "broker_room"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer)
    room_id = Column(Integer)
    created_at = Column(DateTime)
    updated_at = Column(DateTime)


class User(Base):
    __tablename__ = "user"
    
    id = Column(Integer, primary_key = True)
    email = Column(String)
    name = Column(String)

class SubwayCrowding(Base):
    __tablename__ = "subway_crowding"
    
    id = Column(Integer, primary_key = True)
    line_number = Column(Integer)
    start_station = Column(String)
    time_7_00 = Column(Float) #  출근시간
    time_12_00 = Column(Float) # 정오
    time_18_00 = Column(Float) # 퇴근시간
    time_23_00 = Column(Float) # 심야
    
class SubwayInfo(Base):
    __tablename__ = "subwayCoord"
    
    id = Column(Integer, primary_key = True)
    line_num = Column(Integer)
    name = Column(String)
    lat = Column(Float)
    lng = Column(Float)
    